"""
LAYER 3b: Image Forensics Checker
─────────────────────────────────────────────────────────────────────────────
What is image forensics?
  Even after metadata is stripped, the actual pixel arrangement of an image
  contains clues about how it was created.

  Two key techniques we use:

  1. ERROR LEVEL ANALYSIS (ELA)
     When a JPEG is saved, every region compresses to a similar error level.
     If parts of an image were spliced in (edited), those regions will have
     DIFFERENT error levels, creating visible "seams".
     AI images often have unnaturally uniform error levels everywhere.

  2. NOISE PATTERN ANALYSIS
     Real camera sensors add a unique, natural noise pattern to photos.
     AI-generated images have suspiciously smooth, uniform noise — it looks
     "too clean" compared to real photos.

What this file does:
  Runs both checks on the image and returns signal dicts.
"""

import io
import numpy as np
from PIL import Image, ImageFilter


def run_forensics(image_bytes: bytes) -> list[dict]:
    """
    Main function called by app.py.

    Args:
        image_bytes: raw image bytes

    Returns:
        List of signal dicts (same format as metadata_analyzer.py)
    """
    signals = []

    try:
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")

        # ── Check 1: Error Level Analysis ─────────────────────────────────
        ela_signal = _run_ela(image, image_bytes)
        signals.append(ela_signal)

        # ── Check 2: Noise Pattern Analysis ───────────────────────────────
        noise_signal = _run_noise_analysis(image)
        signals.append(noise_signal)

        # ── Check 3: Image dimensions (AI images love round numbers) ───────
        dimension_signal = _check_dimensions(image)
        signals.append(dimension_signal)

    except Exception as e:
        signals.append({
            "layer": "forensics",
            "name": "Forensics Analysis Error",
            "value": f"Could not run forensics: {str(e)}",
            "flag": "neutral",
            "weight": 0
        })

    return signals


# ─────────────────────────────────────────────────────────────────────────────
# HELPER FUNCTIONS (private — not called from outside this file)
# ─────────────────────────────────────────────────────────────────────────────

def _run_ela(original_image: Image.Image, original_bytes: bytes) -> dict:
    """
    Error Level Analysis:
    Re-saves the image at a lower quality, then computes the difference
    between the original and the re-saved version.

    If regions are INCONSISTENT (some much brighter than others in the diff),
    that suggests splicing. If everything is UNIFORMLY flat, that's also
    suspicious (too perfect = likely AI).
    """
    try:
        # Re-save at lower quality
        buffer = io.BytesIO()
        original_image.save(buffer, format="JPEG", quality=75)
        buffer.seek(0)
        recompressed = Image.open(buffer).convert("RGB")

        # Convert both to numpy arrays for math
        original_arr = np.array(original_image, dtype=np.float32)
        recomp_arr = np.array(recompressed, dtype=np.float32)

        # Compute pixel-by-pixel difference
        ela_diff = np.abs(original_arr - recomp_arr)

        # Statistical measures of the difference map
        mean_diff = float(np.mean(ela_diff))
        std_diff = float(np.std(ela_diff))

        # Low mean + very low std = suspiciously uniform (AI pattern)
        if mean_diff < 3.0 and std_diff < 2.0:
            return {
                "layer": "forensics",
                "name": "Error Level Analysis (ELA)",
                "value": f"Suspiciously uniform error levels (mean={mean_diff:.2f}, std={std_diff:.2f}). May indicate AI generation.",
                "flag": "suspicious",
                "weight": 20
            }
        # Very high variance = possible splicing/editing
        elif std_diff > 25.0:
            return {
                "layer": "forensics",
                "name": "Error Level Analysis (ELA)",
                "value": f"High ELA variance detected (std={std_diff:.2f}). Possible image manipulation or splicing.",
                "flag": "suspicious",
                "weight": 15
            }
        else:
            return {
                "layer": "forensics",
                "name": "Error Level Analysis (ELA)",
                "value": f"Normal ELA pattern (mean={mean_diff:.2f}, std={std_diff:.2f}). Consistent with authentic photo.",
                "flag": "clean",
                "weight": 0
            }

    except Exception as e:
        return {
            "layer": "forensics",
            "name": "Error Level Analysis (ELA)",
            "value": f"ELA could not complete: {str(e)}",
            "flag": "neutral",
            "weight": 0
        }


def _run_noise_analysis(image: Image.Image) -> dict:
    """
    Noise Pattern Analysis:
    Applies a blur to the image, then computes the difference between the
    original and blurred versions. This isolates the "noise layer".

    Real cameras: noise is present and has natural variation.
    AI images: noise is too uniform or too absent (suspiciously clean).
    """
    try:
        # Convert to grayscale for noise analysis
        gray = image.convert("L")
        gray_arr = np.array(gray, dtype=np.float32)

        # Apply Gaussian blur
        blurred = gray.filter(ImageFilter.GaussianBlur(radius=2))
        blurred_arr = np.array(blurred, dtype=np.float32)

        # Noise = original minus blurred
        noise = gray_arr - blurred_arr
        noise_std = float(np.std(noise))

        if noise_std < 2.0:
            # Almost no noise = unnaturally clean (common in AI images)
            return {
                "layer": "forensics",
                "name": "Noise Pattern Analysis",
                "value": f"Unusually low noise level (std={noise_std:.2f}). AI images tend to be unnaturally smooth.",
                "flag": "suspicious",
                "weight": 15
            }
        elif noise_std > 20.0:
            # Very noisy — could be a highly compressed/low-quality real photo
            return {
                "layer": "forensics",
                "name": "Noise Pattern Analysis",
                "value": f"High noise level (std={noise_std:.2f}). Consistent with compressed real photo.",
                "flag": "clean",
                "weight": -5
            }
        else:
            return {
                "layer": "forensics",
                "name": "Noise Pattern Analysis",
                "value": f"Normal noise level (std={noise_std:.2f}). Consistent with authentic camera capture.",
                "flag": "clean",
                "weight": -5
            }

    except Exception as e:
        return {
            "layer": "forensics",
            "name": "Noise Pattern Analysis",
            "value": f"Noise analysis failed: {str(e)}",
            "flag": "neutral",
            "weight": 0
        }


def _check_dimensions(image: Image.Image) -> dict:
    """
    Dimension Check:
    AI image generators (Midjourney, DALL-E, Stable Diffusion) produce images
    at very specific sizes: 512x512, 768x768, 1024x1024, 1024x1792, etc.
    Real photos come in all sorts of irregular sizes from cameras.
    """
    AI_COMMON_SIZES = {
        (512, 512), (768, 768), (1024, 1024),
        (1024, 1792), (1792, 1024), (1024, 1536),
        (1536, 1024), (2048, 2048), (1344, 768),
        (768, 1344), (1216, 832), (832, 1216)
    }

    width, height = image.size

    if (width, height) in AI_COMMON_SIZES:
        return {
            "layer": "forensics",
            "name": "Image Dimensions",
            "value": f"{width}x{height}px — matches a known AI generation resolution",
            "flag": "suspicious",
            "weight": 10
        }
    else:
        return {
            "layer": "forensics",
            "name": "Image Dimensions",
            "value": f"{width}x{height}px — non-standard size, consistent with real camera",
            "flag": "clean",
            "weight": 0
        }
