"""
SCORING ENGINE
─────────────────────────────────────────────────────────────────────────────
What this does:
  Collects all the signals from every detection layer and combines them into
  one final risk score between 0 and 100.

  Think of it like a judge hearing multiple witnesses. Each witness (layer)
  says something suspicious or something reassuring. This engine adds up all
  the "suspicion points" and caps the result at 0–100.

Score interpretation (from architecture doc):
  0–30  → Green  — Low Risk (likely authentic)
  31–65 → Yellow — Medium Risk (mixed signals, proceed with caution)
  66–100 → Red   — High Risk (likely AI-generated)

Base score:
  We start at 30 (slightly cautious) and adjust up/down based on signals.
  Signals add positive weights (suspicious) or negative weights (clean).
"""


def calculate_risk_score(signals: list[dict]) -> tuple[int, str]:
    """
    Main function called by app.py.

    Args:
        signals: list of signal dicts from all layers

    Returns:
        Tuple of (risk_score: int, classification: str)
        e.g. (78, "high_risk")
    """

    # Start at a neutral baseline
    BASE_SCORE = 30
    total_adjustment = 0

    for signal in signals:
        weight = signal.get("weight", 0)
        total_adjustment += weight

    # Final score = base + all adjustments, clamped between 0 and 100
    raw_score = BASE_SCORE + total_adjustment
    risk_score = max(0, min(100, raw_score))

    # Classify the score into a category
    classification = _classify_score(risk_score)

    return risk_score, classification


def _classify_score(score: int) -> str:
    """Converts a numeric score into a string classification label."""
    if score <= 30:
        return "low_risk"
    elif score <= 65:
        return "medium_risk"
    else:
        return "high_risk"
