"""
LAYER 4: AI Image Classifier
─────────────────────────────────────────────────────────────────────────────
What this does:
  Sends the image through a pre-trained machine learning model from Hugging Face
  that was trained specifically to tell apart real photos from AI-generated ones.

  Think of it like this: the model has seen millions of real photos AND millions
  of AI-generated images. It learned patterns that distinguish them. Now it looks
  at your image and says "this looks 84% like an AI-generated image."

Which model we use:
  "umm-maybe/AI-image-detector" from Hugging Face
  - Trained on LAION (real photos) vs DALL-E / Midjourney / Stable Diffusion images
  - Returns: { "artificial": 0.84, "real": 0.16 }

  We use the Hugging Face Inference API (free tier) instead of loading the model
  locally, so you don't need a GPU on your Render instance.

HOW TO SET UP THE API KEY:
  1. Go to https://huggingface.co and create a free account
  2. Go to Settings → Access Tokens → New Token (read access is enough)
  3. Copy the token
  4. In Render: go to your service → Environment → Add Variable
     Key:   HF_API_TOKEN
     Value: hf_xxxxxxxxxxxxxxxxxxxx
  5. Never hardcode the token in your code! Always read from environment variable.
"""

import os
import io
import requests

# The Hugging Face model we're using
HF_MODEL_ID = "umm-maybe/AI-image-detector"
HF_API_URL = f"https://api-inference.huggingface.co/models/{HF_MODEL_ID}"


def classify_image(image_bytes: bytes) -> list[dict]:
    """
    Main function called by app.py.

    Args:
        image_bytes: raw bytes of the uploaded image

    Returns:
        List of signal dicts with AI detection result
    """

    # ── Read API token from environment variable ───────────────────────────
    # Never write your token directly in code — use environment variables!
    hf_token = os.environ.get("HF_API_TOKEN")

    if not hf_token:
        # No token set — return a neutral signal instead of crashing
        return [{
            "layer": "ai_detection",
            "name": "AI Model Classifier",
            "value": "Skipped — HF_API_TOKEN environment variable not set",
            "flag": "neutral",
            "weight": 0
        }]

    try:
        # ── Call the Hugging Face Inference API ────────────────────────────
        headers = {"Authorization": f"Bearer {hf_token}"}

        response = requests.post(
            HF_API_URL,
            headers=headers,
            data=image_bytes,          # send raw image bytes in the body
            timeout=30                 # wait max 30 seconds
        )

        # ── Handle API errors ──────────────────────────────────────────────
        if response.status_code == 503:
            # Model is loading (cold start on Hugging Face free tier)
            return [{
                "layer": "ai_detection",
                "name": "AI Model Classifier",
                "value": "Model is warming up on Hugging Face servers. Try again in ~20 seconds.",
                "flag": "neutral",
                "weight": 0
            }]

        if response.status_code != 200:
            return [{
                "layer": "ai_detection",
                "name": "AI Model Classifier",
                "value": f"API error {response.status_code}: {response.text[:100]}",
                "flag": "neutral",
                "weight": 0
            }]

        # ── Parse the result ───────────────────────────────────────────────
        # Response looks like: [{"label": "artificial", "score": 0.84}, {"label": "real", "score": 0.16}]
        results = response.json()
        return _parse_hf_result(results)

    except requests.exceptions.Timeout:
        return [{
            "layer": "ai_detection",
            "name": "AI Model Classifier",
            "value": "Request timed out after 30 seconds",
            "flag": "neutral",
            "weight": 0
        }]

    except Exception as e:
        return [{
            "layer": "ai_detection",
            "name": "AI Model Classifier",
            "value": f"Classifier error: {str(e)}",
            "flag": "neutral",
            "weight": 0
        }]


def _parse_hf_result(api_response: list) -> list[dict]:
    """
    Converts the raw Hugging Face API response into our signal format.

    The API returns something like:
      [{"label": "artificial", "score": 0.84}, {"label": "real", "score": 0.16}]

    We extract the "artificial" score and map it to a risk weight.
    """
    try:
        # Build a dict from the list: {"artificial": 0.84, "real": 0.16}
        scores = {item["label"]: item["score"] for item in api_response}
        ai_probability = scores.get("artificial", 0.0)
        ai_percent = round(ai_probability * 100, 1)

        # ── Map probability to risk weight (per architecture doc) ──────────
        if ai_probability > 0.80:
            weight = 35
            flag = "suspicious"
            interpretation = f"High AI likelihood — model is {ai_percent}% confident this is AI-generated"
        elif ai_probability > 0.50:
            weight = 20
            flag = "suspicious"
            interpretation = f"Moderate AI likelihood — model is {ai_percent}% confident this is AI-generated"
        else:
            weight = -10
            flag = "clean"
            interpretation = f"Low AI likelihood — model is {100 - ai_percent}% confident this is a real photo"

        return [{
            "layer": "ai_detection",
            "name": "AI Model Classifier",
            "value": interpretation,
            "confidence": round(ai_probability, 3),
            "flag": flag,
            "weight": weight
        }]

    except Exception as e:
        return [{
            "layer": "ai_detection",
            "name": "AI Model Classifier",
            "value": f"Could not parse model output: {str(e)}",
            "flag": "neutral",
            "weight": 0
        }]
